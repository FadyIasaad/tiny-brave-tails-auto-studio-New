# Setup Guide — Tiny Brave Tails Auto Studio V2

## What you get

GitHub Actions buttons:

1. Create Upload Bedtime Stories
2. Create Upload Nursery Loops
3. Create Upload Learn Colors
4. Create Upload Learn Numbers ABC
5. Create Upload Animal Adventures
6. Create Upload Calming Music
7. Create Upload Compilation

Each button creates and uploads one video.

## Step 1 — Create a new GitHub repo

Create a new empty repository.

## Step 2 — Upload this ZIP

Upload all files and folders from this ZIP.

## Step 3 — Create playlists on YouTube

Create these playlists:

- Bedtime Stories
- Nursery Loops
- Learn Colors
- Learn Numbers ABC
- Animal Adventures
- Calming Music
- Compilations

## Step 4 — Add playlist IDs

Open `playlist_map.json`.

Replace every `PASTE_..._PLAYLIST_ID` with the real YouTube playlist ID.

## Step 5 — YouTube API token

You need a YouTube OAuth token saved as GitHub Secret:

`YOUTUBE_TOKEN_JSON`

This is required for real uploading.

If you do not add it, the system will still render the video but will run in dry-run mode.

## Step 6 — Run one button

Go to:

GitHub -> Actions

Choose one workflow, for example:

`01 Create Upload Bedtime Stories`

Click:

`Run workflow`

## Step 7 — First uploads should be private

The default privacy is set to private in `config.py`.

Only change it to public after you check quality.

## Important

Free quality will be simple:
- neural but free voices
- 2D scenes
- zoom/pan motion
- simple character drawings
- automated upload

To improve quality, add your own reusable PNG characters and backgrounds to:
- `assets/characters`
- `assets/backgrounds`
